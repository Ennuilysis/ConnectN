
def main() -> None:
    ...  # program execution begins here


if __name__ == '__main__':
    main()
